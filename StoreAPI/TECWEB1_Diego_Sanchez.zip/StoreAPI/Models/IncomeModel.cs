﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreAPI.Models
{
    public class IncomeModel
    {
        //public long Id { get; set; }
        public string ItemName { get; set; }
        public string ItemType { get; set; }
        public float Income { get; set; }
    }
}
